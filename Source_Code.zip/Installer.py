import os
import shutil
import tkinter as tk
from tkinter import messagebox, ttk

# Global states
detected_mod_files = [] # Changed to a list to hold multiple files
found_instances = []
current_launcher = None

def scan_for_mod():
    global detected_mod_files
    source_dir = os.path.join(".", "mod")
    
    # Check if the 'mod' folder exists
    if not os.path.exists(source_dir):
        messagebox.showerror("Error", "Missing the 'mod' folder next to this application!")
        return False
        
    # Look through the folder for all files ending in .jar
    files = os.listdir(source_dir)
    jar_files = [f for f in files if f.endswith(".jar")]
    
    if not jar_files:
        messagebox.showerror("Error", "No Minecraft mods (.jar files) were found inside the 'mod' folder!")
        return False
        
    # Store all matched mod names
    detected_mod_files = jar_files
    return True

def get_launcher_path(launcher_name):
    appdata = os.environ.get("APPDATA")
    user_home = os.path.expanduser("~")
    
    if launcher_name == "Official Minecraft Launcher":
        return os.path.join(appdata, ".minecraft")
    elif launcher_name == "Prism Launcher":
        return os.path.join(appdata, "PrismLauncher", "instances")
    elif launcher_name == "CurseForge":
        return os.path.join(user_home, "curseforge", "minecraft", "Instances")
    elif launcher_name == "Modrinth App":
        return os.path.join(appdata, "ModrinthApp", "profiles")
    return None

def on_launcher_select(event):
    global found_instances, current_launcher
    current_launcher = launcher_var.get()
    found_instances = []
    
    # Reset UI elements
    instance_dropdown['values'] = []
    instance_var.set("")
    feedback_frame.pack_forget()
    instance_frame.pack_forget()
    
    if current_launcher in ["Other (Supported)", "Other (Unsupported)"]:
        handle_other_launchers(current_launcher)
        return

    base_path = get_launcher_path(current_launcher)
    
    if current_launcher == "Official Minecraft Launcher":
        instance_var.set("Default Profile (.minecraft/mods)")
        instance_frame.pack(pady=10)
        return

    if base_path and os.path.exists(base_path):
        for item in os.listdir(base_path):
            full_path = os.path.join(base_path, item)
            if os.path.isdir(full_path):
                found_instances.append(item)
                
    if found_instances:
        instance_dropdown['values'] = found_instances + ["[Create New Instance...]"]
        instance_var.set(found_instances[0])
        instance_frame.pack(pady=10)
    else:
        instance_dropdown['values'] = ["[Create New Instance...]"]
        instance_var.set("[Create New Instance...]")
        instance_frame.pack(pady=10)

def handle_other_launchers(selection):
    if selection == "Other (Supported)":
        messagebox.showinfo("Supported Launchers", "Launchers currently tracked: ATLauncher, Technic Launcher, and GDLauncher.")
        instance_dropdown['values'] = ["ATLauncher Profile", "Technic Pack", "GDLauncher Instance"]
        instance_var.set("ATLauncher Profile")
        instance_frame.pack(pady=10)
    elif selection == "Other (Unsupported)":
        feedback_frame.pack(pady=15)

def run_automatic_install():
    if not detected_mod_files:
        return
        
    launcher = launcher_var.get()
    target_instance = instance_var.get()
    base_path = get_launcher_path(launcher)
    
    # Define general destination directories based on selection
    if target_instance == "[Create New Instance...]":
        if base_path:
            dest_dir = os.path.join(base_path, "Beyond the Fog Pack", "mods")
        else:
            messagebox.showerror("Error", "Could not locate root launcher directory.")
            return
    elif launcher == "Official Minecraft Launcher":
        dest_dir = os.path.join(base_path, "mods")
    elif launcher in ["Prism Launcher", "CurseForge", "Modrinth App"]:
        if launcher == "Prism Launcher":
            dest_dir = os.path.join(base_path, target_instance, ".minecraft", "mods")
        else:
            dest_dir = os.path.join(base_path, target_instance, "mods")
    else:
        messagebox.showwarning("Manual Sync Required", "Please configure the directory targets manually.")
        return

    try:
        os.makedirs(dest_dir, exist_ok=True)
        
        # Loop through EVERY .jar file found inside the mod directory and copy them over
        copied_count = 0
        for mod_file in detected_mod_files:
            source_path = os.path.join(".", "mod", mod_file)
            dest_path = os.path.join(dest_dir, mod_file)
            shutil.copy2(source_path, dest_path)
            copied_count += 1
            
        messagebox.showinfo("Success!", f"Successfully imported {copied_count} mod(s) into your launcher folder:\n{dest_dir}\n\nRestart your launcher to play!")
    except Exception as e:
        messagebox.showerror("Failed", f"Could not write to destination directory:\n{str(e)}")

def send_feedback():
    wanted_launcher = feedback_entry.get().strip()
    if wanted_launcher:
        messagebox.showinfo("Feedback Recorded", f"Thank you! Your request to add support for '{wanted_launcher}' has been logged.")
        feedback_entry.delete(0, tk.END)
    else:
        messagebox.showwarning("Empty Input", "Please type the name of the launcher platform.")

# --- UI Setup ---
window = tk.Tk()
window.title("Crafter Mod Installer")
window.geometry("550x550")
window.configure(bg="#1e1e1e")

if scan_for_mod():
    tk.Label(window, text="Universal Mod Installer", font=("Arial", 16, "bold"), fg="#ffffff", bg="#1e1e1e").pack(pady=15)
    
    # Show the player how many total files were found inside the folder
    total_mods = len(detected_mod_files)
    tk.Label(window, text=f"Ready to deploy: {total_mods} mod file(s) found", font=("Arial", 10, "italic"), fg="#2ea44f", bg="#1e1e1e").pack()

    # Launcher selection block
    tk.Label(window, text="Step 1: Choose Your Active Launcher Platform", font=("Arial", 11, "bold"), fg="#ffffff", bg="#1e1e1e").pack(pady=15)
    launcher_options = ["Official Minecraft Launcher", "Prism Launcher", "CurseForge", "Modrinth App", "Other (Supported)", "Other (Unsupported)"]
    launcher_var = tk.StringVar()
    launcher_dropdown = ttk.Combobox(window, textvariable=launcher_var, values=launcher_options, state="readonly", width=35)
    launcher_dropdown.pack()
    launcher_dropdown.bind("<<ComboboxSelected>>", on_launcher_select)

    # Dynamic Instance Panel Framework
    instance_frame = tk.Frame(window, bg="#1e1e1e")
    tk.Label(instance_frame, text="Step 2: Select Profile / Instance Target Location", font=("Arial", 11, "bold"), fg="#ffffff", bg="#1e1e1e").pack(pady=5)
    instance_var = tk.StringVar()
    instance_dropdown = ttk.Combobox(instance_frame, textvariable=instance_var, state="readonly", width=35)
    instance_dropdown.pack(pady=5)
    
    tk.Button(instance_frame, text="🚀 Complete Mod Deployment", font=("Arial", 12, "bold"), fg="#ffffff", bg="#2ea44f", command=run_automatic_install, width=28).pack(pady=15)

    # Dynamic Feedback Panel Framework
    feedback_frame = tk.Frame(window, bg="#1e1e1e")
    tk.Label(feedback_frame, text="Request Support for Unlisted Platform", font=("Arial", 11, "bold"), fg="#ffffff", bg="#1e1e1e").pack(pady=5)
    feedback_entry = tk.Entry(feedback_frame, width=32, font=("Arial", 10))
    feedback_entry.pack(pady=5)
    tk.Button(feedback_frame, text="Submit Platform Feedback", font=("Arial", 10), fg="#ffffff", bg="#444444", command=send_feedback).pack(pady=5)

window.mainloop()
