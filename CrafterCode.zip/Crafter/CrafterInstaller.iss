#define MyAppName "Crafter"
#define MyAppVersion "0.1.0"
#define MyAppPublisher "Crafter"
#define MyAppExeName "Crafter.exe"

[Setup]
AppId={{65AC7437-5F8A-44CC-A2DD-2AF5EA55D220}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}

DefaultDirName={localappdata}\Programs\Crafter
DisableDirPage=no

DefaultGroupName=Crafter
DisableProgramGroupPage=yes

PrivilegesRequired=lowest

OutputDir=installer
OutputBaseFilename=CrafterSetup

Compression=lzma2
SolidCompression=yes
WizardStyle=modern

UninstallDisplayName=Crafter
UninstallDisplayIcon={app}\Crafter.exe

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Dirs]
Name: "{localappdata}\Crafter"
Name: "{localappdata}\Crafter\mods"
Name: "{localappdata}\Crafter\logs"
Name: "{localappdata}\Crafter\config"

[Files]
Source: "Crafter.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\Crafter"; Filename: "{app}\Crafter.exe"
Name: "{autodesktop}\Crafter"; Filename: "{app}\Crafter.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\Crafter.exe"; Description: "Launch Crafter"; Flags: nowait postinstall skipifsilent